"use strict";


let obgJson;
let itemsCarrinho = [];
let quantidade;
let id = 0;
let quantidadeSelecionada;

const pegarPokemons = async () => {
    //pega a div onde será adicionado os elementos
    let place = document.getElementsByClassName("container")[0]
   

    //Retorna um objeto com o nome e a url
    const obg = await fetch("https://exercicio.herokuapp.com/ ")
    const obgJson = await obg.json()


    
    obgJson.forEach(item => {
        item.quantidade = 0
        item.id = id++ 
    })

    

    //Faz um loop pegando as infos
    obgJson.forEach((qwe, index) => {
        function alterarQwe(){
            qwe.qntSelect = 1
            console.log(qwe.qntSelect);
        }

        //Cria os elementos do iten
        let div = document.createElement("div")
        let img = document.createElement("img")
        let a   = document.createElement("a")
        let adicionarCarrinho = document.createElement("button")


        //Seta atributos aos itens criados
        a.setAttribute("href", "#")
        a.setAttribute("onclick", `adicionarAoCarrinho(${qwe})`)
        a.innerHTML = `<br><p>${qwe.title}</p>`
        a.innerHTML += `<br><p>Valor: ${qwe.price}</p>`
        img.setAttribute("src", qwe.image)  
        adicionarCarrinho.setAttribute("class", "adicionarCarrinho")
        adicionarCarrinho.setAttribute("onclick", "adicionarAoCarrinho()")
        adicionarCarrinho.innerHTML = "Adicionar ao carrinho" 
        div.setAttribute("id", qwe.name)

        

        //Encapsula os itens
        place.appendChild(div)
        div.appendChild(a)
        div.appendChild(adicionarCarrinho)  
        a.appendChild(img)
        
        
    })
    pegarBotao(obgJson)

}

function pegarBotao(elemento){

    let adicionarCarrinho = document.querySelectorAll(".adicionarCarrinho")
    adicionarCarrinho.forEach((item,index) => {
        item.addEventListener("click", () => adicionarAoCarrinho(elemento[index]))
    })
}


function adicionarAoCarrinho(item)
{
    //Declarando variaveis
    let itensSeleciondos = document.querySelector(".itens")
    let base = document.querySelector(".linha")
    let imagemCarrinho = document.querySelector(".imagemCarrinho")
    //.src = items[ites]
    let add = document.querySelector(".add")
    let remove = document.querySelector(".remove")
    let quantidade = document.querySelector(".quantidade")
    console.log(item);
    alterarQwe()
    
    
}



function mostrarCarrinho(){
    let carrinho = document.getElementsByClassName("carrinho")[0]
    if(carrinho.style.display == ""){
        carrinho.style.display = "none"
    }else{
        carrinho.style.display = ""
    }
}



pegarPokemons()